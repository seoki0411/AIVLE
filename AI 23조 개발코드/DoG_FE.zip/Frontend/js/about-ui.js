document.addEventListener("DOMContentLoaded", function () {
    const dogLink = document.getElementById("dog-link");
    if (dogLink) {
        const linkElement = document.createElement("link");
        linkElement.rel = "stylesheet";
        linkElement.href = "css/dog.css";
        document.head.appendChild(linkElement);
    }
});