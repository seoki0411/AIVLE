const agreeAll = document.getElementById('agree-all');
const agreeTerms = document.getElementById('agree-terms');
const disagreeTerms = document.getElementById('disagree-terms');
const agreePersonalInfo = document.getElementById('agree-personal-info');
const disagreePersonalInfo = document.getElementById('disagree-personal-info');
const nextButton = document.getElementById('next-button');

// 전체 동의 체크 버튼 클릭 시
agreeAll.addEventListener('change', () => {
    agreeTerms.checked = agreeAll.checked;
    disagreeTerms.checked = false;
    agreePersonalInfo.checked = agreeAll.checked;
    disagreePersonalInfo.checked = false;
    toggleNextButton();
});

// 동의 체크 버튼 클릭 시
agreeTerms.addEventListener('change', () => {
    if (agreeTerms.checked) disagreeTerms.checked = false;
    agreeAll.checked = agreeTerms.checked && agreePersonalInfo.checked;
    toggleNextButton();
});

agreePersonalInfo.addEventListener('change', () => {
    if (agreePersonalInfo.checked) disagreePersonalInfo.checked = false;
    agreeAll.checked = agreeTerms.checked && agreePersonalInfo.checked;
    toggleNextButton();
});

// 동의하지 않음 체크 버튼 클릭 시
disagreeTerms.addEventListener('change', () => {
    if (disagreeTerms.checked) agreeTerms.checked = false;
    agreeAll.checked = false;
    toggleNextButton();
});

disagreePersonalInfo.addEventListener('change', () => {
    if (disagreePersonalInfo.checked) agreePersonalInfo.checked = false;
    agreeAll.checked = false;
    toggleNextButton();
});

// "다음" 버튼 활성화/비활성화 토글 함수
function toggleNextButton() {
    nextButton.disabled = !(agreeTerms.checked && agreePersonalInfo.checked);
    nextButton.classList.toggle('disabled', nextButton.disabled);
}

// 초기 상태에서 "다음" 버튼 비활성화
toggleNextButton();

// "다음" 버튼 클릭 이벤트
nextButton.addEventListener('click', function () {
    if (!nextButton.disabled) {
        window.location.href = 'signup.html'; // 이동할 페이지의 URL을 여기에 입력합니다.
    }
});
