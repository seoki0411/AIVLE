
// Form submit handler
document.getElementById("qnaForm").addEventListener("submit", function (event) {
  event.preventDefault();
  alert("문의가 정상적으로 등록되었습니다.");
  window.location.href = "qna.html";
});

// Cancel button handler
document.getElementById("cancel-btn").addEventListener("click", function () {
  window.location.href = "qna.html";
});

// 제목 글자 수 제한 체크
document.getElementById("title").addEventListener("input", function () {
  const titleInput = this.value.trim();
  const maxLength = 50;
  const titleInputLength = titleInput.length;

  if (titleInputLength > maxLength) {
    this.classList.add("is-invalid"); // 테두리 빨간색으로 변경
    document.querySelector(".invalid-feedback").style.display = "block"; // 경고 메시지 빨간색으로 변경
  } else {
    this.classList.remove("is-invalid"); // 원래대로 테두리 설정
    document.querySelector(".invalid-feedback").style.display = "none"; // 경고 메시지 원래대로 설정
  }
});