$(".footer").load("../footer.html");
$(document).ready(function() {
    $(".footer").load("../footer.html");
});