document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const userQuery = urlParams.get('query');

    if (userQuery) {
        addMessage(userQuery, 'user');
        getBotResponse(userQuery);
    }

    // Add Enter key event listener
    document.getElementById("inputText").addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            sendMessage();
        }
    });

    // Add click event listener for send button
    document.getElementById("send-btn").addEventListener("click", sendMessage);
});

function addMessage(text, sender, isLoading = false) {
    const chatBox = document.getElementById('chat-box');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const contentDiv = document.createElement('div');
    contentDiv.classList.add('content');
    
    if (isLoading) {
        // Add spinner element if loading
        const spinner = document.createElement('span');
        spinner.classList.add('spinner-border', 'spinner-border-sm');
        spinner.setAttribute('role', 'status');
        spinner.setAttribute('aria-hidden', 'true');
        contentDiv.appendChild(spinner);
        contentDiv.appendChild(document.createTextNode(' Loading...'));
    } else {
        contentDiv.innerText = text;
    }

    messageDiv.appendChild(contentDiv);
    chatBox.appendChild(messageDiv);

    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the latest message
}

function sendMessage() {
    const userInput = document.getElementById('inputText');
    const text = userInput.value.trim();

    if (text !== '') {
        // Disable the send button
        const sendButton = document.getElementById("send-btn");
        sendButton.disabled = true;

        addMessage(text, 'user');
        userInput.value = '';
        getBotResponse(text).finally(() => {
            // Re-enable the send button
            sendButton.disabled = false;
        });
    }
}

function getBotResponse(userText) {
    // Add a loading message with spinner
    addMessage('', 'bot', true);

    return fetch('http://localhost:3000/chatbotQ', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('token'),
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: userText })
    })
    .then(response => response.json())
    .then(data => {
        const botResponse = data;  // Server response
        console.log(botResponse);

        // Remove the loading message and add the actual response
        const chatBox = document.getElementById('chat-box');
        chatBox.removeChild(chatBox.lastChild);
        addMessage(botResponse, 'bot');
    })
    .catch(error => {
        console.error('Error:', error);
        // Remove the loading message and add an error message
        const chatBox = document.getElementById('chat-box');
        chatBox.removeChild(chatBox.lastChild);
        addMessage('죄송합니다. 현재 답변을 할 수 없습니다.', 'bot');
    });
}
