function sendMessage() {
    const inputText = document.getElementById("inputText").value;
    if(inputText){
        $.ajax({
            type: "POST",
            url: `http://localhost:3000/chatbotQ`,
            headers: {'Authorization': 'Bearer ' + localStorage.getItem('token')},                          
            data: JSON.stringify({
                question: inputText,
              }),
            contentType: "application/json",
            success: function (response) {
            // gpt_chatting.html로 넘어가는 코드
            window.location.href = `gpt_chatting.html?query=${encodeURIComponent(inputText)}`;
            },
            error: function (error) {
              console.error("Error response:", error);
              alert(
                error.responseJSON.details.status +
                  ": " +
                  error.responseJSON.details.message
              );
            },
          });
    
    }
}


// Enter 키 이벤트 리스너 추가
document.getElementById("inputText").addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
      sendMessage();
  }
});

function sendExampleMessage(message) {
  window.location.href = `gpt_chatting.html?query=${encodeURIComponent(message)}`;
}
