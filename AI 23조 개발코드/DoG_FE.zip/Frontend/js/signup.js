
document.addEventListener("DOMContentLoaded", function () {
    const signupForm = document.getElementById("signup-form");
    const emailLocalPartInput = document.getElementById("email_local_part");
    const emailDomainInput = document.getElementById("email_domain_input");
    const emailDomainSigninSelect = document.getElementById("email_domain_signin");
    const businessNumberInput = document.getElementById("business-number");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm-password");
    const passwordErrorMessage = document.getElementById("password-error-message");
    const confirmPasswordErrorMessage = document.getElementById("confirm-password-error-message");
    const businessNumberErrorMessage = document.getElementById("business-number-error-message");
    const signupButton = document.getElementById("signup-button");

    function validateForm() {
        const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,10}$/;
        const businessNumberPattern = /^\d+$/; // 숫자만 허용
        const isFormValid = emailLocalPartInput.value && emailDomainInput.value && usernameInput.value &&
            passwordInput.value && confirmPasswordInput.value &&
            passwordPattern.test(passwordInput.value) &&
            businessNumberPattern.test(businessNumberInput.value) &&
            (passwordInput.value === confirmPasswordInput.value);

        if (!passwordPattern.test(passwordInput.value) && passwordInput.value !== "") {
            passwordErrorMessage.innerText = "비밀번호는 영문, 숫자 포함 6~10자여야 합니다.";
            passwordErrorMessage.style.display = "block";
            passwordInput.classList.add("is-invalid");
        } else {
            passwordErrorMessage.style.display = "none";
            passwordInput.classList.remove("is-invalid");
        }

        if (passwordInput.value !== confirmPasswordInput.value && confirmPasswordInput.value !== "") {
            confirmPasswordErrorMessage.innerText = "비밀번호가 일치하지 않습니다.";
            confirmPasswordErrorMessage.style.display = "block";
            confirmPasswordInput.classList.add("is-invalid");
        } else {
            confirmPasswordErrorMessage.style.display = "none";
            confirmPasswordInput.classList.remove("is-invalid");
        }

        if (!businessNumberPattern.test(businessNumberInput.value) && businessNumberInput.value !== "") {
            businessNumberErrorMessage.style.display = "block";
            businessNumberInput.classList.add("is-invalid");
        } else {
            businessNumberErrorMessage.style.display = "none";
            businessNumberInput.classList.remove("is-invalid");
        }

        return isFormValid;
    }

    businessNumberInput.addEventListener("input", function () {
        validateForm();
        const businessNumberPattern = /^\d+$/;
        if (!businessNumberPattern.test(businessNumberInput.value) && businessNumberInput.value !== "") {
            businessNumberErrorMessage.innerText = "사업장 번호는 숫자여야 합니다.";
            businessNumberErrorMessage.style.display = "block";
            businessNumberInput.classList.add("is-invalid");
        } else {
            businessNumberErrorMessage.style.display = "none";
            businessNumberInput.classList.remove("is-invalid");
        }
    });

    passwordInput.addEventListener("input", function () {
        validateForm();
        const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,10}$/;
        if (!passwordPattern.test(passwordInput.value) && passwordInput.value !== "") {
            passwordErrorMessage.innerText = "비밀번호는 영문, 숫자 포함 6~10자여야 합니다.";
            passwordErrorMessage.style.display = "block";
            passwordInput.classList.add("is-invalid");
        } else {
            passwordErrorMessage.style.display = "none";
            passwordInput.classList.remove("is-invalid");
        }

        if (passwordInput.value === confirmPasswordInput.value) {
            confirmPasswordErrorMessage.style.display = "none";
            confirmPasswordInput.classList.remove("is-invalid");
        } else {
            if (confirmPasswordInput.value !== "") {
                confirmPasswordErrorMessage.innerText = "비밀번호가 일치하지 않습니다.";
                confirmPasswordErrorMessage.style.display = "block";
                confirmPasswordInput.classList.add("is-invalid");
            }
        }
    });

    confirmPasswordInput.addEventListener("input", function () {
        validateForm();
        const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,10}$/;
        if (passwordInput.value === confirmPasswordInput.value && passwordPattern.test(passwordInput.value)) {
            confirmPasswordErrorMessage.style.display = "none";
            confirmPasswordInput.classList.remove("is-invalid");
        } else {
            confirmPasswordErrorMessage.innerText = "비밀번호가 일치하지 않습니다.";
            confirmPasswordErrorMessage.style.display = "block";
            confirmPasswordInput.classList.add("is-invalid");
        }
    });

    emailLocalPartInput.addEventListener("input", validateForm);
    emailDomainInput.addEventListener("input", validateForm);
    emailDomainSigninSelect.addEventListener("change", function () {
        emailDomainInput.value = this.value;
        validateForm();
    });
    usernameInput.addEventListener("input", validateForm);
    passwordInput.addEventListener("input", validateForm);

    signupForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (validateForm()) {
            showSignupMessage();
        } else {
            alert("모든 필드를 올바르게 입력해주세요.");
        }
    });
});

function showSignupMessage() {
    var modal = document.getElementById('signup-modal');
    modal.style.display = 'flex';
}

function closeSignupMessage() {
    var modal = document.getElementById('signup-modal');
    modal.style.display = 'none';
    window.location.href = "signin.html";
}
