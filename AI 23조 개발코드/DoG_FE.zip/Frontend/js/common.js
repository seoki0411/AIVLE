$(document).ready(function () {
    AOS.init();

    // 네비게이션 바와 푸터 로드
    $("nav").load("nav.html", function() {
        updateAuthUI(); // 네비게이션 바 로드 후 UI 업데이트
    });
    $("footer").load("footer.html");

    // 로그아웃 함수
    window.logout = function() {
        try {
            alert('로그아웃되었습니다.');
            localStorage.removeItem('token');
            updateAuthUI(); // UI 업데이트
            location.href = 'about.html';
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };

    // 로그인 상태에 따라 네비게이션 바 UI 업데이트
    function updateAuthUI() {
        const token = localStorage.getItem('token');
        if (token) {
            $('#login-link').hide();
            $('#signup-link').hide();
            $('#logout-link').show();
        } else {
            $('#login-link').show();
            $('#signup-link').show();
            $('#logout-link').hide();
        }
    }

    // Storage 이벤트 리스너로 다른 탭에서의 로그아웃 처리
    $(window).on('storage', function(event) {
        if (event.originalEvent.key === 'token') {
            updateAuthUI();
        }
    });
});
