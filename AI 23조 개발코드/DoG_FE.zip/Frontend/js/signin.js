function validateForm() 
{
    // Select the input fields for id and password
    const idInput = document.getElementById('id_signin');
    const pwInput = document.getElementById('pw_signin');

    // Select the error message elements
    const idError = document.getElementById('idError');
    const pwError = document.getElementById('pwError');

    // Check if id input is empty
    if (!idInput.value.trim()) {
        idError.style.display = 'block';
    } else {
        idError.style.display = 'none';
    }

    // Check if password input is empty
    if (!pwInput.value.trim()) {
        pwError.style.display = 'block';
    } else {
        pwError.style.display = 'none';
    }

    // If both fields are filled, submit the form and redirect to about.html
    if (idInput.value.trim() && pwInput.value.trim()) {
        // Directly change window location to about.html after form validation
        window.location.href = 'about.html';
    }
}
