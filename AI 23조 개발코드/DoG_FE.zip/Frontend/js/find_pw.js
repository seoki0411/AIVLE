function toggleAuthMethod() {
    const phoneAuthSection = document.getElementById('phone-auth-section');
    const emailAuthSection = document.getElementById('email-auth-section');
    const phoneRadio = document.getElementById('radio-phone');
    const emailRadio = document.getElementById('radio-email');

    if (phoneRadio.checked) {
        phoneAuthSection.classList.remove('hidden');
        emailAuthSection.classList.add('hidden');
    } else if (emailRadio.checked) {
        phoneAuthSection.classList.add('hidden');
        emailAuthSection.classList.remove('hidden');
    }
}

function getAuthCode(method) {
    // 이 함수는 인증번호를 요청하는 기능을 처리합니다.
    let authData = {};

    if (method === 'phone') {
        const phone = document.getElementById('phone-number').value;
        const countryCode = document.getElementById('countryCode').value;
        authData = { phone: countryCode + phone };
    } else if (method === 'email') {
        const email = document.getElementById('email-address').value;
        authData = { email: email };
    }


    // 임시 메시지
    document.getElementById('result-message').innerText = '인증번호 요청 기능은 아직 구현되지 않았습니다.';
}

document.addEventListener("DOMContentLoaded", function () {
    toggleAuthMethod();
});


function toggleEmailButton() {
    const emailInput = document.getElementById('email-address').value;
    const emailButton = document.getElementById('emailAuthButton');

    if (emailInput.length > 0) {
        emailButton.classList.remove('btn-disabled');
        emailButton.classList.add('btn-active');
        emailButton.disabled = false;
    } else {
        emailButton.classList.remove('btn-active');
        emailButton.classList.add('btn-disabled');
        emailButton.disabled = true;
    }
}
