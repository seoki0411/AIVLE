$('#qnaList-db').on('click-row.bs.table', function (row, element, field) {
    location.href = 'qna-request.html?id='+element.id+'&inquiryType='+element.inquiryType;
});

// 문의 게시글 목록을 가져오는 함수
function getqnaList_ajaxRequest(params) {
  var url = 'http://localhost:3000/board';
  
  $.ajax({
      type: "GET",
      url: url,
      data: params.data, // URL 쿼리 문자열로 추가할 데이터
      headers: {
          'Authorization': 'Bearer ' + localStorage.getItem('token') // 로컬 스토리지에서 가져온 토큰을 Authorization 헤더에 추가
      },
      success: function (res) {
          // 응답 로그
          console.log(res);
          var data = res.data.content;
          
          // 데이터를 Bootstrap Table에 맞게 준비
          var tableData = data.map(function (item, index) {
              return {
                  no: index + 1, // 인덱스 번호 + 1
                  id: item.id,
                  inquiryType: item.inquiryType,
                  title: item.title,
                  createdAt: new Date(item.createdAt).toLocaleDateString(),
                  viewCount: item.viewCount,
              };
          });
  
          // Bootstrap Table에 전달할 데이터 포맷
          params.success({
              total: data.length, // 전체 데이터 개수
              rows: tableData,    // 페이지당 데이터
          });
      },
      error: function (error) {
          console.error('Error fetching data:', error);
          params.error(); // Bootstrap Table의 오류 핸들러 호출
      }
  });
}
