$(document).ready(function () {
  $('#board-db').bootstrapTable({
      onCheck: function (row, element) {
          board_detailFormatter(row, element);
      }
  });
  $('#chatbot-db').bootstrapTable({
      onCheck: function (row, element) {
          console.log(row);
      }
  });
  // 업체정보 클릭시 사업자번호를 통해 회원정보 갖고오기
  $('#company-db').bootstrapTable({
      onCheck: function (row, element) {
          $('#user-db').bootstrapTable('refreshOptions', {
          url: 'json/user.json'
          });          
      }
  });
  $('#waste-db').bootstrapTable({
      onCheck: function (row, element) {
      }
  });

  $("#admin-login-form").on("submit", function (e) {
    e.preventDefault();
    const id = $("#id_signin").val();
    const password = $("#pw_signin").val();
  
    $("#idError").addClass("d-none"); // Hide error initially
    $("#pwError").addClass("d-none");
  
    if (!id) {
      $("#idError").removeClass("d-none"); // Show error if ID is empty
    }
  
    if (!password) {
      $("#pwError").removeClass("d-none"); // Show error if password is empty
    }
  
    if (id && password) {
      $.ajax({
        url: "http://localhost:3000/login",
        type: "POST",
        data: JSON.stringify({ id: id, password: password }),
        contentType: "application/json",
        success: function (data) {
          if (data.message === "Login successful") {
            localStorage.setItem('token', data.token);      
            alert("로그인 성공");
            $("#login-card").addClass("d-none"); // Hide login card after successful login
            // Hide submit button
            $("#login-btn").addClass("d-none");
            
            // Show logout button
            $("#logout-btn").removeClass("d-none");
          } else {
            alert("로그인 실패: " + data.error);
          }
        },
        error: function (error) {
          console.error("Error during login:", error);
          alert("로그인 중 오류가 발생했습니다.");
        },
      });
    }
  });
    
  $("#admin-signup-form").on("submit", function (e) {
    e.preventDefault();
      
    const email = $("#email").val();
    const password = $("#password").val();
    const name = email.split("@")[0];
    const confirmPassword = $("#confirm-password").val();
    let valid = true;
    console.log(email, name, password);
  
    if (!email) {
      $("#email-error").removeClass("d-none"); // Show error if email is empty
      valid = false;
    }
  
    if (!password || !/^(?=.*[a-zA-Z])(?=.*\d).{6,10}$/.test(password)) {
      $("#password-error-message").removeClass("d-none"); // Show error if password is invalid
      valid = false;
    }
  
    if (password !== confirmPassword) {
      $("#confirm-password-error-message").removeClass("d-none"); // Show error if passwords don't match
      valid = false;
    }
  
    if (valid) {
      $.ajax({
        url: "http://localhost:3000/admin-signup",
        type: "POST",
        data: JSON.stringify({ username: email, password: password, name:name, }),
        contentType: "application/json",
        success: function (response) {
          localStorage.setItem('token', response.data.token);
          alert("회원가입 완료");
          $("#signup-card").addClass("d-none"); // Hide signup card after successful signup
          $("#login-card").removeClass("d-none"); // Show login card
        },
        error: function (error) {
          console.error("Error during signup:", error);
          alert("회원가입 중 오류가 발생했습니다.");
        },
      });
    }
  });
});

function confirmLogout(){
  let text="메인 페이지로 이동시 자동으로 로그아웃 됩니다. 이동하시겠습니까?"
  if(confirm(text)){
      localStorage.removeItem('token');
      location.href = '../about.html';
  }
}

// home.html
function hideSignupCard() {
  document.getElementById('signup-card').classList.add('d-none');
}

function showLoginCard() {
  document.getElementById('login-card').classList.remove('d-none');
  document.getElementById('signup-card').classList.add('d-none');
}

function showSignupCard() {
  document.getElementById('signup-card').classList.remove('d-none');
  document.getElementById('login-card').classList.add('d-none');
}
// board.html
function getInquiryType(type) {
    const typeMap = {
        'ACCOUNTS': '계정',
        'USE_OF_SERVICE': '서비스 이용',
        'ETC': '기타'
    };

    return typeMap[type] || type;
}

function getboard_ajaxRequest(params) {
  var url = 'http://localhost:3000/board';
  var token = localStorage.getItem('token');

  $.ajax({
    url: url,
    type: 'GET',
    headers: {
      'Authorization': 'Bearer ' + token
    },
    data: params.data, // Use params.data directly
    success: function (res) {
      res = res.data;
      if (res && res.content) {
        // Prepare the data for Bootstrap Table
        var tableData = res.content.map(function (item, index) {
          return {
            no: index + 1, // Assuming 'no' is the index number + 1
            id: item.id,
            inquiry_type: getInquiryType(item.inquiryType),
            title: item.title,
            view_count: item.viewCount, // Adjusted key to match provided data
            created_at: new Date(item.createdAt).toLocaleDateString(), // Adjusted key to match provided data
          };
        });

        // Return the formatted data to Bootstrap Table
        params.success({
          total: res.content.length,
          rows: tableData,
        });
      } else {
        // Handle case where res.content is undefined or empty
        params.success({
          total: 0,
          rows: [],
        });
      }
    },
    error: function (jqXHR, textStatus, errorThrown) {
      console.error('Error fetching user data:', textStatus, errorThrown);
      params.error();
    }
  });
}

function board_detailFormatter(row, element) {
  console.log(row);
  console.log(element);
  var url = 'http://localhost:3000/board/' + row.id;
  var token = localStorage.getItem('token');

  $.ajax({
      url: url,
      type: 'GET',
      headers: {
          'Authorization': 'Bearer ' + token
      }
  })
  .done(function (res) {
      console.log(res);

      if (res) {
          console.log(res);
          var postData = res;
          $('#inquiry_type').val(getInquiryType(row.inquiry_type) || '');
          $('#title').val(row.title || '');
          $('#description').val(row.description || '');
          $('#username').val(row.username || '');
          $('#createdAt').val(new Date(row.createdAt).toLocaleDateString() || '');
          $('#view_count').val(row.viewCount || '');

          var tableData = postData.comments.map(function (item, index) {
              return {
                  no: index + 1, // Assuming 'no' is the index number + 1
                  name: item.name || '',
                  description: item.description || '',
                  modifiedAt: new Date(item.modifiedAt).toLocaleDateString() || '', // Format date as needed
              };
          });
          $('#comment-db').bootstrapTable('load', tableData);
      }
  })
  .fail(function (jqXHR, textStatus, errorThrown) {
      console.error('Error fetching user data:', textStatus, errorThrown);
  });
}

// chatbot.html

function getchatbot_ajaxRequest(params) {
  var url = 'http://localhost:3000/chatbotList';
  var token = localStorage.getItem('token');

  $.ajax({
    url: url,
    type: 'GET',
    headers: {
      'Authorization': 'Bearer ' + token
    },
    success: function (res) {
      // Log the response for debugging
      console.log(res);

      if (!Array.isArray(res)) {
        // Handle case where response is not an array (single object)
        res = [res]; // Convert single object to an array with one object
      }

      // Prepare the data for Bootstrap Table
      var tableData = res.map(function (item, index) {
        return {
          no: index + 1, // Assuming 'no' is the index number + 1
          question: item.question,
          username: item.username,
          companyName: item.companyName,
        };
      });

      // Return the formatted data to Bootstrap Table
      params.success({
        total: tableData.length,
        rows: tableData,
      });
    },
    error: function (jqXHR, textStatus, errorThrown) {
      console.error('Error fetching user data:', textStatus, errorThrown);
      params.error();
    }
  });
}

// user.html
    
function getuser_ajaxRequest(params) {
  var url = 'http://localhost:3000/userList';
  var token = localStorage.getItem('token');

  $.ajax({
      url: url,
      type: 'GET',
      headers: {
          'Authorization': 'Bearer ' + token
      },
      success: function (res) {
          // Log the response for debugging
          console.log(res);

          if (!Array.isArray(res)) {
              // Handle case where response is not an array (single object)
              res = [res]; // Convert single object to an array with one object
          }

          // Prepare the data for Bootstrap Table
          var tableData = res.map(function (item, index) {
              return {
                  no: index + 1, // Assuming 'no' is the index number + 1
                  username: item.username,
                  businessNumber: item.businessNumber,
                  companyName: item.companyName,
              };
          });

          // Return the formatted data to Bootstrap Table
          params.success({
              total: tableData.length,
              rows: tableData,
          });
      },
      error: function (jqXHR, textStatus, errorThrown) {
          console.error('Error fetching user data:', textStatus, errorThrown);
          params.error();
      }
  });
}

  
  

// waste.html

function getwaste_ajaxRequest(params) {
  var url = 'http://localhost:3000/wasteList';
  var token = localStorage.getItem('token');

  $.ajax({
      url: url,
      type: 'GET',
      headers: {
          'Authorization': 'Bearer ' + token
      },
      success: function (res) {
          // Log the response for debugging
          console.log(res);

          if (!Array.isArray(res)) {
              // Handle case where response is not an array (single object)
              res = [res]; // Convert single object to an array with one object
          }

          // Prepare the data for Bootstrap Table
          var tableData = res.map(function (item, index) {
              return {
                  no: index + 1, // Assuming 'no' is the index number + 1
                  id: item.id,
                  companyName: item.companyName,
                  createdAt: new Date(item.createdAt).toLocaleDateString(), // Format date as needed
                  csvUrl: item.csvUrl,
              };
          });

          // Return the formatted data to Bootstrap Table
          params.success({
              total: tableData.length,
              rows: tableData,
          });
      },
      error: function (jqXHR, textStatus, errorThrown) {
          console.error('Error fetching waste data:', textStatus, errorThrown);
          params.error();
      }
  });
}
