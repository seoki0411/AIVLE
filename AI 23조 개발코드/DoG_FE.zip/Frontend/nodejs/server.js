const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const axios = require("axios");
const app = express();
const path = require("path");
const multer = require('multer');
const FormData = require('form-data');

const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, ".."), { index: false }));


// 토큰 저장소
const tokenStorage = {};

// 미들웨어: 토큰 저장
app.use((req, res, next) => {
  console.log('--app.use');
  console.log('IP:', req.ip);
  console.log('헤더:', req.headers);

  // Authorization 헤더 추출
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    // 'Bearer ' 접두사를 제거하여 토큰 추출
    const token = authHeader.substring(7);

    if (token === 'null' || token === '') {
      req.token = null;
    } else {
      // 클라이언트의 IP를 키로 사용하여 토큰 저장
      tokenStorage[req.ip] = token;
      req.token = token;
    }

    console.log('--authHeader', req.token);
  } else {
    // Authorization 헤더가 없거나 Bearer로 시작하지 않을 때
    req.token = null; // 토큰이 없음을 명시
  }

  // 다음 미들웨어 또는 라우트 핸들러로 진행
  next();
});

// 관리자 회원가입
async function signupAdminToken() {
  try {
    await axios.post("http://localhost:8080/api/v1/admin/signup", {
      username: "email2",
      password: "pw",
      name: "name",
    });
  } catch (error) {
    console.error("Error during admin signup:", error);
    throw error;
  }
}

// 사용자 회원가입
async function signupUserToken(username, password, name, phoneNumber) {
  try {
    await axios.post("http://localhost:8080/api/v1/signup", {
      username: username,
      password: password,
      companyName: name,
      businessNumber: phoneNumber,
    });
  } catch (error) {
    console.error("Error during user signup:", error);
    throw error;
  }
}

// 로그인 후 토큰 반환 함수
async function loginAndGetToken(username, password, req) {
  try {
    const response = await axios.post("http://localhost:8080/login", {
      username: username,
      password: password,
    });

    if (response.status === 200) {
      const token = response.headers.authorization.split(" ")[1];
      req.token = token;
      tokenStorage[req.ip] = token; // 토큰을 저장

      // 관리자 여부 확인
      const isAdmin =
        username === "admin12@naver.com" && password === "123456a";

      return { token, isAdmin };
    } else {
      throw new Error("Failed to login");
    }
  } catch (error) {
    console.error("Error during login:", error);
    throw error;
  }
}

// 문의 게시글 리스트 조회
async function readBoardListRequest(page, size, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.get(
      `http://localhost:8080/api/v1/board/list?page=${page}&size=${size}`,
      {
        headers: token,
      }
    );

    return response; // 서버에서 데이터만 반환
  } catch (error) {
    console.error("Error during GET request:", error);
    throw error; // 에러를 던져서 상위 함수로 전파
  }
}

// 문의 게시글 작성
async function createBoardPostRequest(inquiryType, title, description, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}`, 'Content-Type': 'application/json', } : {'Content-Type': 'application/json',}; // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.post(
      "http://localhost:8080/api/v1/board",
      {
        inquiryType: inquiryType,
        title: title,
        description: description,
      },
      {
        headers: token,
      }
    );

    return response.data;
  } catch (error) {
    console.error(
      "Error during POST request:",
      error.response ? error.response.data : error.message
    );
    throw error;
  }
}

// 문의 게시글 조회
async function readBoardPostRequest(boardId, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.get(
      `http://localhost:8080/api/v1/board/${boardId}`,
      {
        headers: token,
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error during GET request:", error);
    throw error;
  }
}

// POST 요청 처리
app.post("/signup", async (req, res) => {
  console.log("Received POST request on /signup");
  console.log("Request body:", req.body);

  const { emailLocalPart, emailDomain, name, phoneNumber, password } = req.body;
  const username = `${emailLocalPart}@${emailDomain}`;

  try {
    await signupUserToken(username, password, name, phoneNumber);

    res.json({
      message:
        "User signed up, logged in, and board list retrieved successfully",
    });
  } catch (error) {
    console.error("Error in signup process:", error);
    res.status(500).json({
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 문의 게시글 작성 요청 처리
app.post("/qna", async (req, res) => {
  console.log("Received POST request on /qna");
  console.log("Request body:", req.body);

  const { inquiryType, title, description } = req.body;

  try {
    const createdPost = await createBoardPostRequest(
      inquiryType,
      title,
      description,
      req
    );

    console.log("Board post created:", createdPost);

    res.json({
      message: "Board post created successfully",
      createdPost: createdPost,
    });
  } catch (error) {
    console.error("Error in creating board post:", error);
    res.status(500).json({
      error: "Error in creating board post",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 댓글 작성 요청을 서버로 보내는 함수
async function writeBoardCommentPostRequest(boardId, description, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}`,"Content-Type": "application/json", }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.post(
      "http://localhost:8080/api/v1/board/comment",
      {
        boardId: boardId,
        description: description,
      },
      {
        headers: token,
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error during POST request:", error);
    throw error;
  }
}

// 문의 게시글 댓글 작성 요청 처리
app.post("/boardComment", async (req, res) => {
  const { boardId, description } = req.body;

  try {
    const response = await writeBoardCommentPostRequest(boardId, description, req);

    res.status(200).json({
      message: "Comment posted successfully",
      data: response,
    });
  } catch (error) {
    console.error("Error during comment writing:", error);
    res.status(400).json({
      error: "Error during comment writing",
      details: error.response ? error.response.data : error.message,
    });
  }
});


async function deleteBoardPostRequest(boardId, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.delete(
      `http://localhost:8080/api/v1/board/${boardId}`,
      {
        headers: token,
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error during Delete request:", error);
    throw error;
  }
}

// 댓글 삭제
async function deleteBoardCommentRequest(commentId, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.delete(
      `http://localhost:8080/api/v1/board/comment/${commentId}`,
      {
        headers: token,
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error during deleteBoardCommentRequest:", error);
    throw error;
  }
}

app.delete("/board-del/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const msg = await deleteBoardPostRequest(id, req);
    
    res.json({
      message: "Board post deleted successfully",
      data: msg,
    });
  } catch (error) {
    console.error("Error in deleting board post:", error);
    res.status(500).json({
      error: "Error in deleting board post",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 게시글 댓글 삭제 요청 처리
app.delete("/comment-del/:id", async (req, res) => {
  const { id } = req.params; //comment id

  try {
    const response = await deleteBoardCommentRequest(id, req);

    res.json(response);
  } catch (error) {
    console.error("Error in deleting board post:", error);
    res.status(500).json({
      error: "Error in deleting board post",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 문의 게시글 수정 요청 처리
async function updateBoardPost(
  boardId,
  inquiryType,
  title,
  description,
  req
) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.patch(
      `http://localhost:8080/api/v1/board/${boardId}`,
      {
        inquiryType: inquiryType,
        title: title,
        description: description,
      },
      {
        headers: token,
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error during board update:", error);
    throw error;
  }
}

app.patch("/board-edit/:boardId", async (req, res) => {
  const { boardId } = req.params;
  const { inquiryType, title, description } = req.body;

  try {
    const updatedPost = await updateBoardPost(
      boardId,
      inquiryType,
      title,
      description,
      req
    );

    res.status(200).json({
      message: "Board post updated successfully",
      data: updatedPost,
    });
  } catch (error) {
    res.status(500).json({
      error: "Error during board update",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 문의 게시글 삭제 요청 처리
async function deleteBoardPost(boardId, token) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.delete(
      `http://localhost:8080/api/v1/board/${boardId}`,
      {
        headers: token,
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error during board deletion:", error);
    throw error;
  }
}

app.delete("/board-del/:boardId", async (req, res) => {
  const { boardId } = req.params;

  try {
    const deletedPost = await deleteBoardPost(boardId, req.token);

    res.status(200).json({
      message: "Board post deleted successfully",
      data: deletedPost,
    });
  } catch (error) {
    res.status(500).json({
      error: "Error during board deletion",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 로그인 요청 처리
app.post("/login", async (req, res) => {
  const { id, password } = req.body;

  try {
    const { token, isAdmin } = await loginAndGetToken(id, password, req);

    if (token) {
      res.json({ message: "Login successful", token, isAdmin });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch (error) {
    console.error("Error during login:", error);
    res.status(401).json({ error: "Invalid credentials" });
  }
});

app.get("/board/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const readPost = await readBoardPostRequest(id, req);

    console.log("Board post created:", readPost);

    res.status(200).json(readPost.data);
  } catch (error) {
    res
      .status(500)
      .json({ message: "게시판 목록을 가져오는 중 오류가 발생했습니다." });
  }
});

app.get("/board", async (req, res) => {
  try {
    // 예시로 페이지 0, 사이즈 10 사용
    const resBoardList = await readBoardListRequest(0, 10, req);

    // 성공적으로 데이터를 가져온 경우 클라이언트에 반환
    res.status(200).json(resBoardList.data);
  } catch (error) {
    // 오류가 발생한 경우 오류 메시지를 클라이언트에 반환
    res
      .status(500)
      .json({ message: "게시판 목록을 가져오는 중 오류가 발생했습니다." });
  }
});

// 회원 리스트 조회 - 관리자
async function getUserListRequest(req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.get(
      `http://localhost:8080/api/v1/admin/user/list`,
      {
        headers: token,
      }
    );
    console.log(getUserListRequest);
    console.log(response);
    return response.data;
  } catch (error) {
    console.error("Error during getUserListRequest:", error);
    throw error;
  }
}

// 폐기물 처리 정보 조회 - 관리자
async function getwasteListRequest(req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.get(
      `http://localhost:8080/api/v1/admin/waste/list`,
      {
        headers: token,
      }
    );
    console.log('getWasteListRequest');
    console.log(response);
    return response.data;
  } catch (error) {
    console.error("Error during getWasteInfoListRequest:", error);
    throw error;
  }
}

// 챗봇
async function gptrequest(question, req)
{
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    console.log('question: ', question);
    console.log('token: ', token);
    const response = await axios.post(
      `http://localhost:8080/api/v1/ai/gpt`,
      {
        question: question,
      },
      {
        headers: token,
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error during getrequest:", error);
    throw error;
  }
}


app.post("/chatbotQ", async (req, res) => {
  try {
    const request = await gptrequest(req.body.question, req);
    console.log(request.data);
    res.status(200).json(request.data);
    // console.log('dkdkddkdkdkdkkd');
    // res.status(200).json('dkdkddkdkdkdkkd');
  } catch (error) {
    // 오류가 발생한 경우 오류 메시지를 클라이언트에 반환
    res.status(500).json({
      error: "Error during gpt request",
      details: error.response ? error.response.data : error.message,
    });
  }
});


// 챗봇 내역 조회 - 관리자
async function getChatBotListRequest(req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.get(
      `http://localhost:8080/api/v1/admin/chat-bot/list`,
      {
        headers: token,
      }
    );
    console.log(getChatBotListRequest);
    console.log(response);

    return response.data;
  } catch (error) {
    console.error("Error during getChatBotListRequest:", error);
    throw error;
  }
}

// 폐기물량 예측
app.post("/waste-predict", async (req, res) => {
  const {
    area,
    totalFloors,
    duration,
    structure,
    usage,
  } = req.body;

  console.log("Received request body:", req.body);

  try {
    const predictData = await PredictionOfWasteDto(
      area,
      totalFloors,
      duration,
      structure,
      usage,
      req
      );

    console.log("Prediction data received:", predictData);
    res.status(200).json(predictData);
  } catch (error) {
    console.error("Error in /waste-predict route:", error);
    res.status(500).json({
      message: "예측 중 오류가 발생했습니다.",
      details: error.response ? error.response.data : error.message,
    });
  }
});

async function PredictionOfWasteDto(
  area,
  totalFloors,
  duration,
  structure,
  usage,
  req
) {
  console.log("Sending request to external API with data:", {
    area,
    totalFloors,
    duration,
    structure,
    usage,
  });

  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.post(`http://localhost:8080/api/v1/ai/waste`, {
      totalFloorArea: area,
      totalFloors: totalFloors,
      constructionPeriod: duration,
      structure: structure,
      usage: usage,
    },{
      headers: token,
    });

    console.log("Response from external API:", response);
    return response.data;
  } catch (error) {
    console.error(
      "Error during POST request to external API"
    );
    throw error;
  }
}

//이메일 인증
// 이메일 인증 코드 발송 함수
async function sendEmailVerification(email, req) {
  try {
    const response = await axios.post(
      "http://localhost:8080/api/v1/email/send",
      { email: email, verifyCode: "" }
    );
    console.log("Email sent response:", response);
    return response.data;
  } catch (error) {
    console.error(
      "Error during email send request:",
      error.response ? error.response.data : error.message
    );
    throw error;
  }
}

// 이메일 인증 코드 검증 함수
async function verifyEmailCode(email, verifyCode, req) {
  try {
    const response = await axios.post(
      "http://localhost:8080/api/v1/email/verify",
      { email: email, verifyCode: verifyCode }
    );
    console.log("Email verification response:", response.data);
    return response.data;
  } catch (error) {
    console.error(
      "Error during email verify request:",
      error.response ? error.response.data : error.message
    );
    throw error;
  }
}

// 이메일 확인 엔드포인트 추가
app.post("/verify-email", async (req, res) => {
  const { email, verifyCode } = req.body;

  console.log("Received email verification request for:", email, verifyCode);

  try {
    const verifyResult = await verifyEmailCode(email, verifyCode);
    console.log("Email verification successful:", verifyResult);
    res.status(200).json({ message: "이메일 인증 성공", verifyResult });
  } catch (error) {
    if (error.response && error.response.status === 400) {
      console.error("Email verification failed:", error.response.data);
      res.status(400).json({ message: "이메일 인증 실패", details: error.response.data });
    } else {
      console.error("Error during email verification:", error);
      res.status(500).json({
        message: "이메일 인증 중 오류가 발생했습니다.",
        details: error.message,
      });
    }
  }
});

// 이메일 인증 코드 발송 엔드포인트
app.post("/send-email", async (req, res) => {
  const { email } = req.body;
  console.log("Received email send request for:", email);

  try {
    const sendResult = await sendEmailVerification(email);
    console.log("Email sent successfully:", sendResult);
    res.status(200).json({ message: "이메일 발송 완료", sendResult });
  } catch (error) {
    console.error("Error during email send:", error);
    res.status(500).json({
      message: "이메일 발송 중 오류가 발생했습니다.",
      details: error.message,
    });
  }
});

async function changePassword(username, password) {
  try {
    const response = await axios.post("http://localhost:8080/api/v1/user/password", {
      username: username,
      password: password
    });
    console.log("Password change response:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error during password change request:", error.response ? error.response.data : error.message);
    throw error;
  }
}

app.post("/reset-password", async (req, res) => {
  const { username, password } = req.body;
  console.log("Received password reset request for:", username);

  try {
    const response = await  changePassword(username, password);
    console.log("Password reset successful:", response.data);
    res.status(200).json({ message: "비밀번호 변경 완료", data: response.data });
  } catch (error) {
    console.error("Error during password reset:", error);
    res.status(500).json({
      message: "비밀번호 변경 중 오류가 발생했습니다.",
      details: error.message,
    });
  }
});

// 폐기물 인식 
app.post("/recommend-facility", async (req, res) => {
  const { region, folderName } = req.body;
  console.log("Received facility recommendation request for:", region, folderName);

  try {
    const response = await FacilityRequestDto(region, folderName, req);
    console.log("response: ", response);
    console.log("Facility recommendation successful:", response.data);
    res.status(200).json({ message: "업체 추천 완료", data: response.data });
  } catch (error) {
    res.status(500).json({
    });
  }
});

async function FacilityRequestDto(region, folderName, req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정
    const response = await axios.post("http://localhost:8080/api/v1/ai/facility", {
      region: region,
      folderName: folderName,
    },{
      headers: token,
    });
    console.log("Facility recommendation response:");
    return response.data;
  } catch (error) {
    console.error("Error during Facility recommendation request:", error.response ? error.response.data : error.message);
    throw error;
  }
}

// 추가된 부분...
// 관리자 회원가입
async function adminSignupRequest(username, password, name, req) {
  try {
    const response = await axios.post(
    `http://localhost:8080/api/v1/admin/signup`,
    {
    username: username,
    password: password,
    name: name,
    },
  );
  return response.data;
  } catch (error) {
    console.error("Error during adminSignupRequest:", error);
    throw error;
  }
}
app.post("/admin-signup", async (req, res) => {
const { username, password, name } = req.body;

try {
  console.log(username, password, name);
  const results = await adminSignupRequest(username, password, name, req);
  res.status(200).json(results.data);
  } catch (error) {
    res.status(500).json({
    error: "Check server.js",
      details: error.response ? error.response.data : error.message,
    });
  }
});

// 챗봇 내역 조회 - 관리자
app.get("/chatbotList", async (req, res) => {
  
  try {
    const results = await getChatBotListRequest(req);
    res.status(200).json(results.data);
    } catch (error) {
      res.status(500).json({
      error: "Check server.js",
        details: error.response ? error.response.data : error.message,
      });
    }
  });
  
// 회원리스트 조회 - 관리자
app.get("/userList", async (req, res) => {
  
  try {
    const results = await getUserListRequest(req);
    res.status(200).json(results.data);
    } catch (error) {
      res.status(500).json({
      error: "Check server.js",
        details: error.response ? error.response.data : error.message,
      });
    }
  });

// 폐기물리스트 조회 - 관리자
app.get("/wasteList", async (req, res) => {
  
  try {
    const results = await getwasteListRequest(req);
    res.status(200).json(results.data);
    } catch (error) {
      res.status(500).json({
      error: "Check server.js",
        details: error.response ? error.response.data : error.message,
      });
    }
  });

//이미지 분류
const storage = multer.memoryStorage();
const upload = multer();


app.post("/image", upload.single("file"), async (req, res) => {

  console.log(req.file);
  if (!req.file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  try {
    const response = await SeperateRequestDto(req);
    res.status(200).json({ message: "이미지 분류 완료", data: response });
  } catch (error) {
    console.error(
      "Error uploading file:",
      error.response ? error.response.data : error.message
    );
    res
      .status(500)
      .json({ message: "Error uploading file", error: error.message });
  }
});

async function SeperateRequestDto(req) {
  try {
    const token = req.token != null ? { Authorization: `Bearer ${req.token}` }  : {};  // 토큰이 없는 경우 빈 문자열이 아니라 null로 설정

    // Prepare the form data
    const formData = new FormData();
    formData.append('file', req.file.buffer, req.file.originalname);
  
    const response = await axios.post(
      "http://localhost:8080/api/v1/ai/image",
      formData,
      {
        headers: token,
      }
    );

    console.log("image response:", response.data);
    return response.data;
  } catch (error) {
    if (error.response) {
      console.error("Error response data:", error.response.data);
      console.error("Error response status:", error.response.status);
      console.error("Error response headers:", error.response.headers);
    } else if (error.request) {
      console.error("Error request data:", error.request);
    } else {
      console.error("Error message:", error.message);
    }
    throw error;
  }
}
  

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'about.html')); 
});



app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});