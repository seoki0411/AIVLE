package aivle.dog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoGApplicationTests {

    @Test
    void contextLoads() {
    }

}
