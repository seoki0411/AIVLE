package aivle.dog.global.enums;

public interface EnumValue<T> {
    T getDbValue();
    String getDesc();
}